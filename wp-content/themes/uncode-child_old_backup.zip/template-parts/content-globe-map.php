<div class="globe-map">
	<h2>		
		<span class="title-blue-authenia">Finest Source</span>
		<span class="title-light">FROM AROUND THE GLOBE</span>
	</h2>

	<?php add_revslider('globe-map-slider'); ?>

	<div class="bottom-text">
		<p class="body-l">Our mission at Pacific West is to bring the finest food from around the globe to</p>
		<p class="body-l">Australian’s plates, whether at a restaurant, pub, cafe or in their own home.</p>
		<p class="body-l">We’re passionate about everything food!</p>
	</div>
</div>