<?php get_header();?>

<div class="not-in-menu">
<?php get_template_part('/template-parts/content-brand-selector-custom');?>
</div>

<?php get_template_part('/template-parts/content-view-wholesalers');?>

<?php get_template_part('/template-parts/content-contact-block');?>

<?php get_footer();?>