<div class="contact container full-container">
	<div class="row">
		<div class="col-md-6 left">
			<h2 class="title-m-bold">HAVE A QUESTION ABOUT OF PRODUCTS?</h2>
			<p class="body-l">Leave us a message and we’ll be in touch asap.</p>
			<p class="body-l address"><strong>3 Trent Road, North Rocks NSW 2151</strong></p>
			<a class="blue-link" href="tel:1800888388">1800 888 388</a>
			<a class="blue-link" href="mailto: info@pacificwest.com.au">info@pacificwest.com.au</a>
		</div>

		<div class="col-md-6 right">
			<!-- iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3316.4659187614448!2d151.01065381520775!3d-33.77446458068251!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6b12a3c62581fb43%3A0x2b7ca0c46c10384f!2s3%20Trent%20Rd%2C%20North%20Rocks%20NSW%202151!5e0!3m2!1sen!2sau!4v1645762548263!5m2!1sen!2sau" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe -->
			<iframe width="100%" height="450" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=+(Pacific%20West%203%20Trent%20Road,%20North%20Rocks%20NSW%202151)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe>
		</div>
	</div>
</div>